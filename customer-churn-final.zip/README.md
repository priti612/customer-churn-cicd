# Telecom Customer Churn Prediction – CI/CD

## 1. Project setup
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Train and evaluate models
Keep the examiner Excel file at `data/customer_churn.xlsx`, then run:
```bash
python train.py --data data/customer_churn.xlsx
```
The script compares Logistic Regression and Random Forest using a stratified 80:20 split. It selects the model with the highest Churn-class F1 score and saves it to `artifacts/churn_model.joblib`.

## 3. Run tests
```bash
pytest -v
```

## 4. Run FastAPI
```bash
uvicorn app:app --reload
```
Open `http://127.0.0.1:8000/docs`.
- `GET /health`
- `POST /predict`

## 5. Docker
```bash
docker build -t customer-churn:latest .
docker run -p 8000:8000 customer-churn:latest
```

## 6. GitHub and GHCR
Create a GitHub repository and push the project:
```bash
git init
git add .
git commit -m "Initial customer churn application"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```
The GitHub Actions workflow runs on pushes to `main`. It installs dependencies, validates Python files, runs tests, builds the Docker image, and on a push to `main`, publishes the image to GHCR. The workflow uses the built-in `GITHUB_TOKEN`; no personal access token is required when repository package permissions allow it.

After a successful workflow:
```bash
docker pull ghcr.io/USERNAME/customer-churn:latest
docker run -p 8000:8000 ghcr.io/USERNAME/customer-churn:latest
```
Replace `USERNAME` with your GitHub username. For a private GHCR package, authenticate with `docker login ghcr.io` before pulling.
